package sop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sop.models.Product;
import sop.models.ProductImage;

import sop.repositories.ProductImageRepository;
import sop.repositories.ProductRepositories;
import sop.utils.Views;

@Controller
@RequestMapping("/admin/product")
public class ProductController {
	 @Autowired
	 ProductRepositories repPro;	
	 @Autowired 
	 ProductImageRepository repProImage;
	 @GetMapping("")
	 public String index(Model model) {    
	     List<Product> products = repPro.findAll();
	     List<ProductImage> lsImage = repProImage.findAll();

	     for (Product product : products) {
	         boolean hasMainImage = false;
	         for (ProductImage image : lsImage) {
	             if (image.getProductId() == product.getId() && image.getMainStatus() == 1) {
	                 hasMainImage = true;
	                 break;
	             }
	         }
	         if (!hasMainImage) {
	             ProductImage noImage = new ProductImage();
	             noImage.setProductId(product.getId());
	             noImage.setFileName("noimage.jpg");
	             noImage.setMainStatus(1); // giả sử bạn muốn đánh dấu đây là ảnh chính
	             lsImage.add(noImage);
	         }
	     }

	     model.addAttribute("product", products);
	     model.addAttribute("lsImage", lsImage);
	     return Views.PRODUCT_INDEX;
	 }

	 @GetMapping("/create")
	    public String newProduct(Model model) {
			
	        Product product = new Product();
	        product.setTitle("");
	        product.setPrice(0);
	        product.setStatus(0);
	        model.addAttribute("newProduct", product);
	        return Views.PRODUCT_CREATE;  // Assuming this is the Thymeleaf template name
	    }

	    @PostMapping("/newProduct")
	    public String submitProduct(
	            @RequestParam("title") String title,
	            @RequestParam("price") double price,
	            @RequestParam("status") int status) {
	        Product product = new Product();
	        product.setTitle(title);
	        product.setPrice(price);
	        product.setStatus(status);
	        repPro.addProduct(product);
	        return "redirect:/admin/product";
	    }
	    @GetMapping("/productdetail/{id}")
	    public String getProductDetails(@PathVariable("id") int id, Model model) {
	        // Find the product by ID
	        Product product = repPro.findById(id);
	        if (product != null) {
	            model.addAttribute("product", product);
	            
	            // Retrieve images related to the product
	            List<ProductImage> lsImage = repProImage.findAll(); // Assuming a method to filter images by productId
	            model.addAttribute("lsImage", lsImage);
	            
	            return Views.PRODUCT_DETAIL; // Assuming Views.PRODUCT_DETAIL is a constant that refers to your Thymeleaf template
	        } else {
	            model.addAttribute("error", "Product not found");
	            return "error"; // Assuming you have an error view to display when the product is not found
	        }
	    }

}


















