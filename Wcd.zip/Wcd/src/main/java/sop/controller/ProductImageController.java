package sop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import sop.models.Product;
import sop.models.ProductImage;
import sop.repositories.ProductImageRepository;
import sop.repositories.ProductRepositories;
import sop.utils.FileUtility;
import sop.utils.Views;

@Controller
@RequestMapping("/admin/productimage")
public class ProductImageController {
	 @Autowired
	 ProductRepositories repPro;	
	 @Autowired 
	 ProductImageRepository repProImage;
	 @GetMapping("")
	    public String index(Model model) {	    
	        model.addAttribute("product", repProImage.findAll());
	        return Views.PRODUCT_IMAGE_INDEX;
	    }
	 @GetMapping("/addImage")
	    public String newProductImage(Model model) {		
	        ProductImage productImage = new ProductImage();
	        model.addAttribute("productImage", productImage);
	        List<Product> lsPro = repPro.findAll();
	        model.addAttribute("lsPro",lsPro);
	        return Views.PRODUCT_IMAGE_CREATE;
	    }
	 @PostMapping("/new")
	    public String submitProductImage(
	            @RequestParam("mainStatus") int mainStatus,
	            @RequestParam("productId") int productId,
	            @RequestParam("fileName") MultipartFile image) {
	        ProductImage productImage = new ProductImage();
	        productImage.setFileName(FileUtility.uploadFileImage(image, "Uploads"));
	        productImage.setMainStatus(mainStatus);
	        productImage.setProductId(productId);
	        repProImage.newIamge(productImage);

	        return "redirect:/admin/product";
	    }
}
