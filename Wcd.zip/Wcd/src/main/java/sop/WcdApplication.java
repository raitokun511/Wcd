package sop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WcdApplication {

	public static void main(String[] args) {
		SpringApplication.run(WcdApplication.class, args);
	}

}
