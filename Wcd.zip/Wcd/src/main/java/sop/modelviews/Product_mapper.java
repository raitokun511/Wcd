package sop.modelviews;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import sop.utils.Views;
import sop.models.Product;

public class Product_mapper implements RowMapper<Product>{
	@Override
	 public Product mapRow(ResultSet rs, int RowNume) throws SQLException {
	        Product product = new Product();
	       product.setId(rs.getInt(Views.COL_PRODUCT_ID));
	       product.setTitle(rs.getString(Views.COL_PRODUCT_TITLE));
	       product.setPrice(rs.getDouble(Views.COL_PRODUCT_PRICE));
	       product.setStatus(rs.getInt(Views.COL_PRODUCT_STATUS));
	        return product;
	        
	    }
	
}
