package sop.modelviews;

import org.springframework.jdbc.core.RowMapper;
import sop.models.ProductImage;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductImagemapper implements RowMapper<ProductImage> {
    @Override
    public ProductImage mapRow(ResultSet rs, int rowNum) throws SQLException {
        ProductImage productImage = new ProductImage();
        productImage.setId(rs.getInt("_id"));
        productImage.setFileName(rs.getString("_file_name"));
        productImage.setMainStatus(rs.getInt("_main_status"));
        productImage.setProductId(rs.getInt("_id_pro"));
        return productImage;
    }
}
