package sop.repositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import sop.models.Product;
import sop.models.ProductImage;
import sop.modelviews.ProductImagemapper;
import sop.modelviews.Product_mapper;
import sop.utils.Views;

import java.util.List;

@Repository
public class ProductImageRepository {

    @Autowired
    private JdbcTemplate db;
    
    public List<ProductImage> findAll() {
        String sql = String.format("SELECT * FROM %s",Views.TBL_PRODUCT_IMAGE);
        return db.query(sql, new ProductImagemapper());
    }
    public String newIamge(ProductImage newItem) {
		try {
			String str_query= String.format("insert into %s values( ?, ?, ?)",Views.TBL_PRODUCT_IMAGE);
			int  rowaccept = db.update(str_query, new Object[] {
					newItem.getFileName(),
					newItem.getMainStatus(),
					newItem.getProductId(), });
			if(rowaccept==1) {
				return "success";
			}
			return "faile";
		}catch(Exception e) {
			
		}
		return "insert exception data";
	}
   
}
