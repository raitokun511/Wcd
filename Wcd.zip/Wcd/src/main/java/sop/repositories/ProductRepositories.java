package sop.repositories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import sop.models.Product;
import sop.utils.Views;
import sop.modelviews.*;

@Repository
public class ProductRepositories {
	@Autowired
	JdbcTemplate db;
	
	public List<Product> findAll() {
        String sql = String.format("SELECT * FROM %s",Views.TBL_PRODUCT);
        return db.query(sql, new Product_mapper());
    }
	public int addProduct(Product product) {
        String sql = String.format("INSERT INTO %s (%s, %s, %s) VALUES ( ?, ?, ?)",
        		Views.TBL_PRODUCT,
                Views.COL_PRODUCT_TITLE,
                Views.COL_PRODUCT_PRICE,
                Views.COL_PRODUCT_STATUS);
        return db.update(sql, product.getTitle(), product.getPrice(), product.getStatus());
    }
	public Product findById(int id) {
		String str_query = String.format("select * from %s where %s=?", Views.TBL_PRODUCT,
				Views.COL_PRODUCT_ID);
		return db.queryForObject(str_query, new Product_mapper(),new Object[] {id});
	}
}
