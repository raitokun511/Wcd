package sop.models;

public class ProductImage {
    private int id;
    private String fileName;
    private int mainStatus;
    private int productId;

    // Default constructor
    public ProductImage() {
        this.id = 0;
        this.fileName = "no-name.jpg";
        this.mainStatus = 0;
        this.productId = 0;
    }

    // Parameterized constructor
    public ProductImage(int id, String fileName, int mainStatus, int productId) {
        this.id = id;
        this.fileName = fileName;
        this.mainStatus = mainStatus;
        this.productId = productId;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getMainStatus() {
        return mainStatus;
    }

    public void setMainStatus(int mainStatus) {
        this.mainStatus = mainStatus;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}
