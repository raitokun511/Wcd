package sop.utils;

import java.util.List;

import sop.models.ProductImage;

public class ProductImageService {

    private List<ProductImage> productImages;

    public ProductImageService(List<ProductImage> productImages) {
        this.productImages = productImages;
    }

    public void setMainStatus(int imageId, int status) throws IllegalArgumentException {
        if (status != 0 && status != 1) {
            throw new IllegalArgumentException("Invalid status. Only 0 or 1 is allowed.");
        }

        if (status == 1) {
            // Ensure only one image has mainStatus of 1
            for (ProductImage image : productImages) {
                if (image.getMainStatus() == 1 && image.getId() != imageId) {
                    image.setMainStatus(0);
                }
            }
        }

        // Set the status of the specified image
        ProductImage imageToUpdate = findProductImageById(imageId);
        if (imageToUpdate != null) {
            imageToUpdate.setMainStatus(status);
        } else {
            throw new IllegalArgumentException("Image with the specified ID not found.");
        }
    }

    private ProductImage findProductImageById(int id) {
        for (ProductImage image : productImages) {
            if (image.getId() == id) {
                return image;
            }
        }
        return null;
    }
}
